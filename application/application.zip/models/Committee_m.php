<?php


class Committee_m extends My_model
{

	protected $table = "committee";
}
