<?php


class Transaction_detail_m extends My_model
{
	protected $primaryKey = "id";
	protected $table = "transaction_details";
}
