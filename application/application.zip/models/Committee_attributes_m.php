<?php


class Committee_attributes_m extends My_model
{

	protected $table = "committee_attributes";
}
