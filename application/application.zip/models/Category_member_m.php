<?php


class Category_member_m extends MY_Model
{
    protected $table = "kategory_members";
    protected $primaryKey = "id";


}