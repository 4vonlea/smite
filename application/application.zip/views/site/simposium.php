<section class="page-header page-header-color page-header-quaternary page-header-more-padding custom-page-header" style="margin-bottom:0px">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1>Rundown</h1>
            </div>
            <div class="col-lg-6">
                <ul class="breadcrumb d-block text-md-right breadcrumb-light">
                    <li><a href="">Home</a></li>
                    <li class="active">Rundown</li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="custom-section-padding">
    <div class="container">
        <div class="row mb-3">
            <div class="col-lg-12">
            <div class="owl-carousel owl-theme nav-inside float-left mr-4 mb-2" data-plugin-options="{'items': 1, 'margin': 10, 'animateOut': 'fadeOut','autoplay': true}">
            <img alt="" class="" src="<?= base_url('themes/porto'); ?>/img/jadwal.jpg">
            </div>
            </div>
        </div>
    </div>
</section>